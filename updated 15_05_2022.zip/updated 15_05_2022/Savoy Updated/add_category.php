
 <div class="bg-image" 
     style="background-image: url('home.jpg');
            height: 100vh">
<?php
  include "header.php";
  require 'includes/dbh.inc.php';
  ?>

  <link rel="stylesheet" href="timepicker.css">
  <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
 
<br><br>
<div class="container-fluid">
    <h3 class="text-center"><br>New Staff Timing<br></h3>   
    <div class="row">
        <div class="col-md-6 offset-md-3">   

        
        <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
   
    <script>
//      function setCookie(name,value,days) {
//     var expires = "";
//     if (days) {
//         var date = new Date();
//         date.setTime(date.getTime() + (days*24*60*60*1000));
//         expires = "; expires=" + date.toUTCString();
//     }
//     document.cookie = name + "=" + (value || "")  + expires + "; path=/";
// }
// function getCookie(name) {
//     var nameEQ = name + "=";
//     var ca = document.cookie.split(';');
//     for(var i=0;i < ca.length;i++) {
//         var c = ca[i];
//         while (c.charAt(0)==' ') c = c.substring(1,c.length);
//         if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
//     }
//     return null;
// }

function calculateTime(start,end) {
        //get values
        var valuestart = start;
        var valuestop =end;
        var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;
         //create date format          
         var timeStart = new Date("1970-1-1 " + valuestart);
         var timeEnd = new Date("1970-1-1 " + valuestop);

         var difference = timeEnd - timeStart;             

         difference = difference / 60 / 60 / 1000;


 return difference

}
function onTimeChange2(id) {
  var b="."+id;
    
    var ids =id;
    // alert(id)
    var lastChar = ids.slice(0, -1);
    var days1="#"+lastChar;
    var d="."+lastChar;
var days2="#"+id;

 
  // alert(lastChar)
// alert(b);
    //   check that value if it is previous date or not
   //create date format          
// alert($(days2).val())
//create date format         
// alert(calculateTime( $(days1).val(), $(days2).val()))

    if ( calculateTime( $(days1).val(), $(days2).val()) == 0) {
     alert("you cannot enter previous time or same time");
      // if upper alert occur then after dissappear of alert it will empty the field
      $(days2).val(' ');  
      
  }
  else{
    var inputEle = document.getElementById(id);
    var timeSplit = inputEle.value.split(':'),
    hours,
    minutes,
    meridian;
  hours = timeSplit[0];
  minutes = timeSplit[1];
  if (hours > 12) {
    meridian = 'PM';
    hours -= 12;
  } else if (hours < 12) {
    meridian = 'AM';
    if (hours == 0) {
      hours = 12;
    }
  } else {
    meridian = 'PM';
  }
 
//   inputEle.setAttribute("type","text");
//   inputEle.value=hours + ':' + minutes + ' ' + meridian;
  document.getElementsByClassName(id).value="hdsaio"+ hours + ':' + minutes + ' ' + meridian;
  
  if ($(b).val()==" " || $(b).val()== null || $(b).val( )== "" )  {
    // alert(id)
    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  else{


    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  
//   alert(hours + ':' + minutes + ' ' + meridian);
  }

   
}
  
function onTimeChange(id) {
  var b="."+id;

    var inputEle = document.getElementById(id);
    var timeSplit = inputEle.value.split(':'),
    hours,
    minutes,
    meridian;
  hours = timeSplit[0];
  minutes = timeSplit[1];
  if (hours > 12) {
    meridian = 'PM';
    hours -= 12;
  } else if (hours < 12) {
    meridian = 'AM';
    if (hours == 0) {
      hours = 12;
    }
  } else {
    meridian = 'PM';
  }
 
//   inputEle.setAttribute("type","text");
//   inputEle.value=hours + ':' + minutes + ' ' + meridian;
  document.getElementsByClassName(id).value="hdsaio"+ hours + ':' + minutes + ' ' + meridian;
  
  if ($(b).val()==" " || $(b).val()== null || $(b).val( )== "" )  {
    // alert(id)
    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  else{


    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  
//   alert(hours + ':' + minutes + ' ' + meridian);
}

    </script>    
    
<?php
if(isset($_SESSION['user_id'])){
    echo '<p class="text-white bg-dark text-center">Welcome  '. $_SESSION['username'] .', Create staff schedule here!</p> <span><a href="Category_detail.php"><button class="btn btn-sm btn-primary m-3 p-2">All Category</button></a> </span>';
      
  //error handling:
    
    if(isset($_GET['error3'])){
        if($_GET['error3'] == "emptyfields") {   //douleuei bazw ta errors apo ta headers.. prp na bgalw to requiered
            echo '<h5 class="bg-danger text-center">Fill all fields, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidfname") {   
            echo '<h5 class="bg-danger text-center">Invalid First Name, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidlname") {   
            echo '<h5 class="bg-danger text-center">Invalid Last Name, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidtele") {   
            echo '<h5 class="bg-danger text-center">Invalid Telephone, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "invalidcomment") {   
            echo '<h5 class="bg-danger text-center">Invalid Comment, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "invalidguests") {   
            echo '<h5 class="bg-danger text-center">Invalid Guests, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "full") {   
            echo '<h5 class="bg-danger text-center">Reservations are full this date and timezone, Please try again!</h5>';
        }
    }
        if(isset($_GET['category'])) {   
           if($_GET['category'] == "success"){ 
            echo '<h5 class="bg-success text-center">Your category was successfull!</h5>';
        }
        }
        echo'<br>';



        date_default_timezone_set('Australia/Sydney');

    $date=date("Y-m-d");
    
     //reservation form  
 ?>
        
    <div class="signup-form">
        <form action="includes/add_category.inc.php" method="post">
        
        <div class="mb-3">
          <label for="" class="form-label">Add category </label>
          <input type="text"
            class="form-control" name="category" id="category" aria-describedby="helpId" placeholder="">
          <small id="helpId" class="form-text text-muted">Add category  </small>
        </div>

            <div class="form-group">
		<label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
            </div>
            <div class="form-group">
            <button type="submit" name="staff-submit" class="btn btn-dark btn-lg btn-block">Submit Reservation</button>
            </div>
        </form>
        <br><br>
    </div>
    
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

<?php
    }

    else {
        echo '	<p class="text-center text-danger"><br>You are currently not logged in!<br></p>
       <p class="text-center">In order to make a reservation you have to create an account!<br><br><p>';  
        
    }
    ?>

             
        </div>
    </div>
</div>
<br><br>


<?php
  include "footer.php";
  ?>
</div>