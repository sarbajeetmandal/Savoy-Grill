<?php


//delete reservation

if(isset($_GET['id'])) {
 
 require 'includes/dbh.inc.php';
 
 $reservation_id = $_GET['id'];
    
 $sql = "SELECT * FROM `menu` WHERE id =$reservation_id";
if (mysqli_query($conn, $sql)) {
    $run=mysqli_query($conn, $sql);
   $row=mysqli_fetch_assoc($run);
   echo "<a href='view_menu.php' style='font-size:1.7rem'> Go Back </a>
   <h1> Description</h1>
   <hr>";
     readfile("description/".$row["description"]);
echo"<hr>";
} else {
 
    header("Location: ../staff_detail.php?delete=error");
}
}
else{
    echo '
    <p class="text-center  text-danger">In order to delete you have to first access the schedule page<br><br><p>
    <script>
    setTimeout(function(){
     window.location.href ="view_menu.php"; 
}, 4000);
   
    </script>
    ';  
}






mysqli_close($conn);
?>

    


