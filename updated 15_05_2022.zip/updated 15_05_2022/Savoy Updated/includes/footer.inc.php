<?php

session_start();

//between function.. elenxei an oi xaraktires einai mesa sta oria p thetoume
function between($val, $x, $y){
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

if(isset($_POST['footer-submit'])) {//elenxw an exei bei sti selida mesw tou submit

    require 'dbh.inc.php';
$id=1;
 
   
    $opening_hour= $_POST['start_time']."-".$_POST['end_time2'];
    $hours= $_POST['hours'];
    $Email= $_POST['Email'];
    $number= $_POST['number'];
    $location= $_POST['location'];
        
        
    if (!isset($opening_hour) || !isset($hours) || !isset($Email) || !isset($number) || !isset($location)) {
        header("Location: ../Edit_footer.php?error3=emptyfields");
        exit();
    } else {
  

        $sql = "UPDATE `footer` SET `opening_hour`='{$opening_hour}',`hours`='{$hours}',`Email`='{$Email}'
        ,`number`='{$number}',`location`='{$location}' WHERE 1 ";
        $stmt = mysqli_query($conn,$sql);
    
  
    header("Location: ../Edit_footer.php?staff=success");
    exit();
    
}
    
//    mysqli_stmt_close($stmt);
   mysqli_close($conn);
}
    


