<?php


//delete reservation

if(isset($_POST['menu_id'])) {
 
 require 'dbh.inc.php';
 
 $cat_id = $_POST['menu_id'];
    
 
 $sql_check = "SELECT * FROM `menu` WHERE id =$cat_id";
 
$run= mysqli_query($conn, $sql_check);

if (mysqli_num_rows($run)>0) {
    $row_description=mysqli_fetch_assoc($run);
    unlink("../description/{$row_description["description"]}");
    $sql2 = "DELETE FROM `menu` WHERE  id =$cat_id";
        # code...

    if ( mysqli_query($conn, $sql2)) {
   
        header("Location: ../view_menu.php?delete=success");
    } else {
        header("Location: ../view_menu.php?delete=error");
    }
}

}
else{
    echo '
    <p class="text-center  text-danger">In order to delete you have to first access the Category page<br><br><p>
    <script>
    setTimeout(function(){
     window.location.href ="view_menu.php"; 
}, 4000);
   
    </script>
    ';  
}






mysqli_close($conn);
?>

    


