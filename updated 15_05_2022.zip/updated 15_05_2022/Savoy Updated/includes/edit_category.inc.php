<?php

session_start();

//between function.. elenxei an oi xaraktires einai mesa sta oria p thetoume
function between($val, $x, $y){
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

if(isset($_POST['staff-submit'])) {//elenxw an exei bei sti selida mesw tou submit

    require 'dbh.inc.php';
$category=$_POST["category"];
$cat_id=$_POST["cat_id"];
    
    if (!isset($category) || empty($category) ) {
        header("Location: ../edit_category.php?error3=emptyfields&&cat_id={$cat_id}");
        exit();
    } else {
  

        $sql = "UPDATE `category` SET `name`='{$category}' where id='{$cat_id}'";
        $stmt = mysqli_query($conn,$sql);
    
  
    header("Location: ../edit_category.php?category=success&&cat_id={$cat_id}");
    exit();
    
}
    
//    mysqli_stmt_close($stmt);
   mysqli_close($conn);
}
    


