<?php


if(isset($_SESSION['user_id'])){
    
    require 'includes/dbh.inc.php';

    
    $user = $_SESSION['user_id'];
    $role = $_SESSION['role'];
    
    //rolos pelati
    if($role==3){
        $sql = "SELECT * FROM `staff` where staff_id='{$user}'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
           
            
            echo
            '
                <table class="table table-hover table-bordered table-responsive-sm text-center">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Staff Name</th>
                            <th scope="col">Monday</th>
                            <th scope="col">Tuesday</th>
                            <th scope="col">Wednesday</th>
                            <th scope="col">Thursday</th>
                            <th scope="col">Friday</th>
                            <th scope="col">Saturday</th>
                            <th class="table-danger" scope="col">Sunday</th>
                          
                        </tr>
                    </thead> ';
                    $i=0;
            while($row = $result->fetch_assoc()) {
    $sql23 = "SELECT * FROM `users` where user_id={$row["staff_id"]}";
                $result23 = $conn->query($sql23);
                $row23 = $result23->fetch_assoc();
    
            $i++;
            if ($row["Monday"]== "0-0") {
                $monday= "Holiday/OFF";
                $class1="bg-danger text-text-white";
            }
            else{
                $monday= $row["Monday"];
                $class1=" ";
            }
        //  ===============================
            if ($row["Tuesday"]== "0-0") {
                $Tuesday= "Holiday/OFF";
                $class2="bg-danger text-text-white";
            }
            else{
                $Tuesday= $row["Tuesday"];
                $class2=" ";
            }
            //  ===============================
            if ($row["Wednesday"]== "0-0") {
                $Wednesday= "Holiday/OFF";
                $class3="bg-danger text-text-white";
            }
            else{
                $Wednesday= $row["Wednesday"];
                $class3=" ";
            } 
                  //  ===============================
                  if ($row["Thursady"]== "0-0") {
                    $Thursady= "Holiday/OFF";
                    $class4="bg-danger text-text-white";
                }
                else{
                    $Thursady= $row["Thursady"];
                    $class4=" ";
                } 
                     //  ===============================
                     if ($row["Friday"]== "0-0") {
                        $Friday= "Holiday/OFF";
                        $class5="bg-danger text-text-white";
                    }
                    else{
                        $Friday= $row["Friday"];
                        $class5=" ";
                    } 
                          //  ===============================
                          if ($row["Saturday"]== "0-0") {
                            $Saturday= "Holiday/OFF";
                            $class6="bg-danger text-text-white";
                        }
                        else{
                            $Saturday= $row["Saturday"];
                            $class6=" ";
                        } 
            echo"
                    <tbody>
                        <tr>
                        
                          <input name='id' type='hidden' value=".$row["id"].">
                          <th scope='row'>".$i."</th> 
                          <td>".$row23["uidUsers"]."</td>
                          <td  class='".$class1."' >".$monday."</td>
                          <td class='".$class2."'>".$Tuesday."</td>
                          <td class='".$class3."'>".$Wednesday."</td>
                          <td class='".$class4."'>".$Thursady."</td>
                          <td class='".$class5."'>".$Friday."</td>
                          <td class='".$class6."'>".$Saturday."</td>
                           
                          <td class='table-danger'>Holiday/OFF</td>
                                                       
                        </tr>
                  </tbody>";
                
            }   
            echo "</table>";
        
        
        } 
    else {    echo "<p class='text-white text-center bg-danger'>Your reservation list is empty!<p>"; }
    }
    
    
    //rolos upeuthinou 
    
    else if($role==2){
    $sql = "SELECT * FROM `staff`";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
       
        
        echo
        '
            <table class="table table-hover table-bordered table-responsive-sm text-center">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Staff Name</th>
                        <th scope="col">Monday</th>
                        <th scope="col">Tuesday</th>
                        <th scope="col">Wednesday</th>
                        <th scope="col">Thursday</th>
                        <th scope="col">Friday</th>
                        <th scope="col">Saturday</th>
                        <th class="table-danger" scope="col">Sunday</th>
                        <th class="table-danger" scope="col">Edit</th>
                        <th class="table-danger" scope="col">Delete</th>
                        
                    </tr>
                </thead> ';
                $i=0;
        while($row = $result->fetch_assoc()) {
$sql23 = "SELECT * FROM `users` where user_id={$row["staff_id"]}";
            $result23 = $conn->query($sql23);
            $row23 = $result23->fetch_assoc();

        $i++;
        if ($row["Monday"]== "0-0") {
            $monday= "Holiday/OFF";
            $class1="bg-danger text-text-white";
        }
        else{
            $monday= $row["Monday"];
            $class1=" ";
        }
    //  ===============================
        if ($row["Tuesday"]== "0-0") {
            $Tuesday= "Holiday/OFF";
            $class2="bg-danger text-text-white";
        }
        else{
            $Tuesday= $row["Tuesday"];
            $class2=" ";
        }
        //  ===============================
        if ($row["Wednesday"]== "0-0") {
            $Wednesday= "Holiday/OFF";
            $class3="bg-danger text-text-white";
        }
        else{
            $Wednesday= $row["Wednesday"];
            $class3=" ";
        } 
              //  ===============================
              if ($row["Thursady"]== "0-0") {
                $Thursady= "Holiday/OFF";
                $class4="bg-danger text-text-white";
            }
            else{
                $Thursady= $row["Thursady"];
                $class4=" ";
            } 
                 //  ===============================
                 if ($row["Friday"]== "0-0") {
                    $Friday= "Holiday/OFF";
                    $class5="bg-danger text-text-white";
                }
                else{
                    $Friday= $row["Friday"];
                    $class5=" ";
                } 
                      //  ===============================
                      if ($row["Saturday"]== "0-0") {
                        $Saturday= "Holiday/OFF";
                        $class6="bg-danger text-text-white";
                    }
                    else{
                        $Saturday= $row["Saturday"];
                        $class6=" ";
                    } 
        echo"
                <tbody>
                    <tr>
                    
                      <input name='id' type='hidden' value=".$row["id"].">
                      <th scope='row'>".$i."</th> 
                      <td>".$row23["uidUsers"]."</td>
                      <td  class='".$class1."' >".$monday."</td>
                      <td class='".$class2."'>".$Tuesday."</td>
                      <td class='".$class3."'>".$Wednesday."</td>
                      <td class='".$class4."'>".$Thursady."</td>
                      <td class='".$class5."'>".$Friday."</td>
                      <td class='".$class6."'>".$Saturday."</td>
                       
                      <td class='table-danger'>Holiday/OFF</td>
                      <td class='table-danger'><a href='Edit_staff.php?id={$row["id"]}'  class='btn btn-danger btn-sm'>Edit</a></td>
                      <td class='table-danger'><a href='includes/delete_staff.php?id={$row["id"]}' class='btn btn-danger btn-sm'>Delete</a></td>
                          
                    </tr>
              </tbody>";
            
        }   
        echo "</table>";
    
    
    }
    else {    echo "<p class='text-white text-center bg-danger'>Your schedule Table is empty!<p>"; }
    
    }
    


mysqli_close($conn);
}


