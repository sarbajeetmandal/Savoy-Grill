<?php


//delete reservation

if(isset($_POST['Active-submit'])) {
 
 require 'dbh.inc.php';
 
 $id = $_POST['user_id'];
 if ($_POST['status']==0) {
     $status=1;
 }   
 else{
    $status=0;
 }

 $sql = "UPDATE `users` SET `status`='{$status}' WHERE `user_id` =$id";
if (mysqli_query($conn, $sql)) {
    header("Location: ../staff_approvel.php?Status=success");
} else {
    header("Location: ../staff_approvel.php?Status=error");
}
}
else{
    echo '
    <p class="text-center  text-danger">In order to update you have to first access the Staff list page<br><br><p>
    <script>
    setTimeout(function(){
     window.location.href ="staff_approvel.php"; 
}, 4000);
   
    </script>
    ';  
}






mysqli_close($conn);
?>

    


