<?php


//delete reservation

if(isset($_POST['cat_id'])) {
 
 require 'dbh.inc.php';
 
 $cat_id = $_POST['cat_id'];
    
 $sql = "DELETE FROM `category` WHERE id =$cat_id";
 $sql_check = "SELECT * FROM `menu` WHERE cat_id =$cat_id";
 
$run= mysqli_query($conn, $sql_check);

if (mysqli_num_rows($run)>0) {
    $row_description=mysqli_fetch_assoc($run);
    unlink("../description/{$row_description["description"]}");
    $sql2 = "DELETE FROM `menu` WHERE   cat_id =$cat_id";
    mysqli_query($conn, $sql2);     # code...
 }

 if (mysqli_query($conn, $sql)) {
   
    header("Location: ../Category_detail.php?delete=success");
} else {
    header("Location: ../Category_detail.php?delete=error");
}
}
else{
    echo '
    <p class="text-center  text-danger">In order to delete you have to first access the Category page<br><br><p>
    <script>
    setTimeout(function(){
     window.location.href ="Category_detail.php"; 
}, 4000);
   
    </script>
    ';  
}






mysqli_close($conn);
?>

    


