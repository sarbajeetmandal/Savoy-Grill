<?php

session_start();

//between function.. elenxei an oi xaraktires einai mesa sta oria p thetoume
function between($val, $x, $y){
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

if(isset($_POST['staff-submit'])) {//elenxw an exei bei sti selida mesw tou submit

    require 'dbh.inc.php';
$id=$_POST["id"];
    $monday= $_POST['Monday'];
    $monday_time= $_POST['Monday_time'] ."-".$_POST['Monday_time2'] ;
    $tuesday= $_POST['Tuesday'];
    $tuesday_time= $_POST['Tuesday_time']."-".$_POST['Tuesday_time2'];
    $wednesday= $_POST['Wednesday'];
    $wednesday_time= $_POST['Wednesday_time']."-".$_POST['Wednesday_time2'];
    $thursday= $_POST['Thursday'];
    $thursday_time= $_POST['Thursday_time']."-".$_POST['Thursday_time2'];
    $friday= $_POST['Friday'];
    $friday_time= $_POST['Friday_time']."-".$_POST['Friday_time2'];
    $saturday= $_POST['Saturday'];
    $saturday_time= $_POST['Saturday_time']."-".$_POST['Saturday_time2'];
    
    
    if (!isset($monday_time) || !isset($tuesday_time) || !isset($wednesday_time) || !isset($thursday_time) || !isset($friday_time) || !isset($saturday_time)) {
        header("Location: ../Edit_staff.php?id={$id}&&error3=emptyfields");
        exit();
    } else {
  

        $sql = "UPDATE `staff` SET `Monday`='{$monday_time}',`Tuesday`='{$tuesday_time}',`Wednesday`='{$wednesday_time}'
        ,`Thursady`='$thursday_time',`Friday`='{$friday_time}',`Saturday`='{$saturday_time}' WHERE id='{$id}' ";
        $stmt = mysqli_query($conn,$sql);
    
  
    header("Location: ../Edit_staff.php?id={$id}&&staff=success");
    exit();
    
}
    
//    mysqli_stmt_close($stmt);
   mysqli_close($conn);
}
    


