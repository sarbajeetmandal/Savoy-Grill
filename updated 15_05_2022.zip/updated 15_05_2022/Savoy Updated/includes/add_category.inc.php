<?php

session_start();

//between function.. elenxei an oi xaraktires einai mesa sta oria p thetoume
function between($val, $x, $y){
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

if(isset($_POST['staff-submit'])) {//elenxw an exei bei sti selida mesw tou submit

    require 'dbh.inc.php';
$category=$_POST["category"];
    
    if (!isset($category) || empty($category) ) {
        header("Location: ../add_category.php?error3=emptyfields");
        exit();
    } else {
  

        $sql = "INSERT INTO `category`(`name`)
        VALUES ('{$category}')";
        $stmt = mysqli_query($conn,$sql);
    
  
    header("Location: ../add_category.php?category=success");
    exit();
    
}
    
//    mysqli_stmt_close($stmt);
   mysqli_close($conn);
}
    


