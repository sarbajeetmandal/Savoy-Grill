<?php

session_start();
require 'dbh.inc.php';
//between function.. elenxei an oi xaraktires einai mesa sta oria p thetoume
function between($val, $x, $y){
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

if(isset($_POST['staff-submit'])) {//elenxw an exei bei sti selida mesw tou submit

    
$p_name=$_POST["p_name"];
$cat_id=$_POST["cat_id"];
$price=$_POST["price"];
$edit_id=$_POST["edit_id"];
    
    if (!isset($p_name) || empty($p_name) || !isset($cat_id) || empty($cat_id) || !isset($price) || empty($price) || !isset($edit_id) || empty($edit_id) ) {
        header("Location: ../edit_menu.php?error3=emptyfields&&menu_id={$edit_id}");
        exit();
    } else {
  
if (isset($_POST["description"]) && !empty($_POST["description"])) {
    # code...
    $description=$_POST["description"];
    $sql_description = "SELECT * FROM `menu` WHERE id = '{$edit_id}'";
    $run_description = mysqli_query($conn,$sql_description);
    $row_description = mysqli_fetch_assoc($run_description);
// for description
if (file_exists("../description/{$row_description["description"]}")) {
    unlink("../description/{$row_description["description"]}");
  
      $i = rand(5,99);
        $myfile_2 = "p_discription_{$i}.text";
      
      $myfile = fopen("../description/p_discription_{$i}.text", "w") or die("Unable to open file!");
          $txt = $description;
          fwrite($myfile, $txt);               
          fclose($myfile);
  } // Description Close
  

  $sql_update="UPDATE `menu` SET 
  `cat_id`='{$cat_id}',`p_name`='{$p_name}',`Price`='{$price}',`description`='{$myfile_2}' WHERE id={$edit_id}";
        $stmt23 = mysqli_query($conn,$sql_update);
        if ($stmt23) {
            header("Location: ../edit_menu.php?menu=success&&menu_id={$edit_id}");
            exit();
        } 
        else{
            header("Location: ../edit_menu.php?error3=emptyfields&&menu_id={$edit_id}");
        
        }    
        
}

else{

$sql_update="UPDATE `menu` SET 
    `cat_id`='{$cat_id}',`p_name`='{$p_name}',`Price`='{$price}' WHERE id={$edit_id}";
          $stmt23 = mysqli_query($conn,$sql_update);
if ($stmt23) {
    header("Location: ../edit_menu.php?menu=success&&menu_id={$edit_id}");
    exit();
} 
else{
    header("Location: ../edit_menu.php?error3=emptyfields&&menu_id={$edit_id}");

}    
        // 
        }


  
    
    
}
    
//    mysqli_stmt_close($stmt);
   mysqli_close($conn);
}
    


