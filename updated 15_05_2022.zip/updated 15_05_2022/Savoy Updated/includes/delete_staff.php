<?php


//delete reservation

if(isset($_GET['id'])) {
 
 require 'dbh.inc.php';
 
 $reservation_id = $_GET['id'];
    
 $sql = "DELETE FROM `staff` WHERE id =$reservation_id";
if (mysqli_query($conn, $sql)) {
    header("Location: ../staff_detail.php?delete=success");
} else {
    header("Location: ../staff_detail.php?delete=error");
}
}
else{
    echo '
    <p class="text-center  text-danger">In order to delete you have to first access the schedule page<br><br><p>
    <script>
    setTimeout(function(){
     window.location.href ="staff_detail.php"; 
}, 4000);
   
    </script>
    ';  
}






mysqli_close($conn);
?>

    


