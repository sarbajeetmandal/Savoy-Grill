<?php

session_start();

//between function.. elenxei an oi xaraktires einai mesa sta oria p thetoume
function between($val, $x, $y){
    $val_len = strlen($val);
    return ($val_len >= $x && $val_len <= $y)?TRUE:FALSE;
}

if(isset($_POST['staff-submit'])) {//elenxw an exei bei sti selida mesw tou submit

    require 'dbh.inc.php';
$category=$_POST["cat_id"];
$p_name=$_POST["p_name"];
$price=$_POST["price"];
$description=$_POST["description"];
    
    if (!isset($category) || empty($category) ) {
        header("Location: ../add_menu.php?error3=emptyfields");
        exit();
    } else {
        $i = rand(5,99);
        $myfile_2 = "p_discription_{$i}.text";
        $myfile = fopen("../description/p_discription_{$i}.text", "w") or die("Unable to open file!");
        $txt = $description;
        fwrite($myfile, $txt);               
        fclose($myfile);
    

        $sql = "INSERT INTO `menu` (`cat_id`, `p_name`, `Price`, `description`)
        VALUES ('{$category}','{$p_name}','{$price}','$myfile_2')";
        $stmt = mysqli_query($conn,$sql);
    
  
    header("Location: ../add_menu.php?category=success");
    exit();
    
}
    
//    mysqli_stmt_close($stmt);
   mysqli_close($conn);
}
    


