<!--footer-->
<footer class="footer" id="footer">
 <div class="container"><br>
  <div class="row">
    <div class="col-sm-12 text-center">
      <div class="social-icon">
        <a href="index.php"><i class="fa fa-facebook"></i></a>
        <a href="index.php"><i class="fa fa-twitter"></i></a>
        <a href="index.php"><i class="fa fa-pinterest"></i></a>
        <a href="index.php"><i class="fa fa-rss"></i></a>
      </div>
      <div class="copyright">
        <p class="white"> copyright &copy;<a href="http://localhost/Restaurant-Reservation/index.php"><strong><em>Savoy Grill-Bar and Restaurant</em></strong></a></p>
        <p><i class="fa fa-phone"></i> 040 456 7890 &nbsp;<i class="fa fa-envelope-o"></i>Savoy@gmail.com</p>
      </div>
    </div>
  </div>
 </div>
</footer>
<!--end of footer-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<script>
  $(window).scroll(function(e){ 
     var windowsize = $(window).width();
    // alert($(window).width()  )
    // windowsize < 992 && windowsize > 779
        
            
            
  var $el = $('.fixedElement1'); 
  var $el2 = $('.fixedElement2'); 
  var isPositionFixed = ($el2.css('position') == 'fixed');
  if ($(this).scrollTop() > 150 && !isPositionFixed){
    // $el.css({'position': 'fixed', 'top': '0px',"z-index":"100"}); 	
    $el2.css({'position': 'fixed', 'top': '0rem',"z-index":"100","background-color":"#23262B"}); 
  }
  if ($(this).scrollTop() < 150 && isPositionFixed){
    // $el.css({'position': 'static', 'top': '0px'}); 
    $el2.css({'position': 'static', 'top': '0px',"z-index":"100","background-color":"transparent"}); 
  } 
        
    
});

</script>
</body>
<!---end of body-->
</html>