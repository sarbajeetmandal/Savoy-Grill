
 <div class="bg-image" 
     style="background-image: url('home.jpg');
            height: 100vh">
<?php
  include "header.php";
  require 'includes/dbh.inc.php';
  ?>

  <link rel="stylesheet" href="timepicker.css">
  <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
 
<br><br>
<div class="container-fluid">
    <h3 class="text-center"><br>New Staff Timing<br></h3>   
    <div class="row">
        <div class="col-md-6 offset-md-3">   

        
        <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
   
    <script>
//      function setCookie(name,value,days) {
//     var expires = "";
//     if (days) {
//         var date = new Date();
//         date.setTime(date.getTime() + (days*24*60*60*1000));
//         expires = "; expires=" + date.toUTCString();
//     }
//     document.cookie = name + "=" + (value || "")  + expires + "; path=/";
// }
// function getCookie(name) {
//     var nameEQ = name + "=";
//     var ca = document.cookie.split(';');
//     for(var i=0;i < ca.length;i++) {
//         var c = ca[i];
//         while (c.charAt(0)==' ') c = c.substring(1,c.length);
//         if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
//     }
//     return null;
// }

function calculateTime(start,end) {
        //get values
        var valuestart = start;
        var valuestop =end;
        var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;
         //create date format          
         var timeStart = new Date("1970-1-1 " + valuestart);
         var timeEnd = new Date("1970-1-1 " + valuestop);

         var difference = timeEnd - timeStart;             

         difference = difference / 60 / 60 / 1000;


 return difference

}
function onTimeChange2(id) {
  var b="."+id;
    
    var ids =id;
    // alert(id)
    var lastChar = ids.slice(0, -1);
    var days1="#"+lastChar;
    var d="."+lastChar;
var days2="#"+id;

 
  // alert(lastChar)
// alert(b);
    //   check that value if it is previous date or not
   //create date format          
// alert($(days2).val())
//create date format         
// alert(calculateTime( $(days1).val(), $(days2).val()))

    if ( calculateTime( $(days1).val(), $(days2).val()) == 0) {
     alert("you cannot enter previous time or same time");
      // if upper alert occur then after dissappear of alert it will empty the field
      $(days2).val(' ');  
      
  }
  else{
    var inputEle = document.getElementById(id);
    var timeSplit = inputEle.value.split(':'),
    hours,
    minutes,
    meridian;
  hours = timeSplit[0];
  minutes = timeSplit[1];
  if (hours > 12) {
    meridian = 'PM';
    hours -= 12;
  } else if (hours < 12) {
    meridian = 'AM';
    if (hours == 0) {
      hours = 12;
    }
  } else {
    meridian = 'PM';
  }
 
//   inputEle.setAttribute("type","text");
//   inputEle.value=hours + ':' + minutes + ' ' + meridian;
  document.getElementsByClassName(id).value="hdsaio"+ hours + ':' + minutes + ' ' + meridian;
  
  if ($(b).val()==" " || $(b).val()== null || $(b).val( )== "" )  {
    // alert(id)
    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  else{


    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  
//   alert(hours + ':' + minutes + ' ' + meridian);
  }

   
}
  
function onTimeChange(id) {
  var b="."+id;

    var inputEle = document.getElementById(id);
    var timeSplit = inputEle.value.split(':'),
    hours,
    minutes,
    meridian;
  hours = timeSplit[0];
  minutes = timeSplit[1];
  if (hours > 12) {
    meridian = 'PM';
    hours -= 12;
  } else if (hours < 12) {
    meridian = 'AM';
    if (hours == 0) {
      hours = 12;
    }
  } else {
    meridian = 'PM';
  }
 
//   inputEle.setAttribute("type","text");
//   inputEle.value=hours + ':' + minutes + ' ' + meridian;
  document.getElementsByClassName(id).value="hdsaio"+ hours + ':' + minutes + ' ' + meridian;
  
  if ($(b).val()==" " || $(b).val()== null || $(b).val( )== "" )  {
    // alert(id)
    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  else{


    $(b).val(hours + ':' + minutes + ' ' + meridian);
  }
  
//   alert(hours + ':' + minutes + ' ' + meridian);
}

    </script>    
    
<?php
if(isset($_SESSION['user_id'])){
    echo '<p class="text-white bg-dark text-center">Welcome  '. $_SESSION['username'] .', Create staff schedule here!</p> <span><a href="staff_detail.php"><button class="btn btn-sm btn-primary m-3 p-2">All schedule</button></a> </span>';
      
  //error handling:
    
    if(isset($_GET['error3'])){
        if($_GET['error3'] == "emptyfields") {   //douleuei bazw ta errors apo ta headers.. prp na bgalw to requiered
            echo '<h5 class="bg-danger text-center">Fill all fields, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidfname") {   
            echo '<h5 class="bg-danger text-center">Invalid First Name, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidlname") {   
            echo '<h5 class="bg-danger text-center">Invalid Last Name, Please try again!</h5>';
        }
        else if($_GET['error3'] == "invalidtele") {   
            echo '<h5 class="bg-danger text-center">Invalid Telephone, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "invalidcomment") {   
            echo '<h5 class="bg-danger text-center">Invalid Comment, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "invalidguests") {   
            echo '<h5 class="bg-danger text-center">Invalid Guests, Pleast try again!</h5>';
        }
        else if($_GET['error3'] == "full") {   
            echo '<h5 class="bg-danger text-center">Reservations are full this date and timezone, Please try again!</h5>';
        }
    }
        if(isset($_GET['staff'])) {   
           if($_GET['staff'] == "success"){ 
            echo '<h5 class="bg-success text-center">Your Staff schedule was successfull!</h5>';
        }
        }
        echo'<br>';



        date_default_timezone_set('Australia/Sydney');

    $date=date("Y-m-d");
    
     //reservation form  
 ?>
        
    <div class="signup-form">
        <form action="includes/staff_accept.inc.php" method="post">
        <div>
        <div class="form-group">
        
                  <label for="staff_name" class="form-label">Staff Name</label>
                  <select class="form-control" name="staff_name" id="staff_name">
                  <?php 
                   $sql = "SELECT * FROM users WHERE role_id=3"; 
                   $run=mysqli_query($conn,$sql);
                   if (mysqli_num_rows($run)>0) {
                       while ($row=mysqli_fetch_assoc($run)) {
                     
                   ?>
                   <option value="<?php echo $row["user_id"] ?>"><?php echo $row["uidUsers"] ?></option>
                <?php   }
                   }?> 
                </select>
              
           
        </div>
        </div>   
        <div class="form-group">
            <h3>Select  Time respectively to days </h3>
    <div class="mb-3">

      <select class="form-control" name="Monday" id="Monday">
        <option value="1">Monday</option>
        <option value="0">Holiday/Off</option>
      </select>
    </div>       
    </div>   
           
            <div class="form-group">
		<label>Enter Time Zone</label>
        <input type="time" onchange="onTimeChange(this.id)"  id="Monday_time" placeholder="time" required="required">
        <input type="hidden"  name="Monday_time" class="Monday_time "  id="Monday_time" >
        <input type="time" onchange="onTimeChange2(this.id)"  id="Monday_time2" placeholder="time" required="required">
        <input type="hidden"  name="Monday_time2" class="Monday_time2"  id="Monday_time" >
    </div>
        <!-- tuesday -->
        <div class="form-group">
    <div class="mb-3">
      <label for="day" class="form-label"></label>
      <select class="form-control" name="Tuesday" id="Tuesday">
        <option value="2">Tuesday</option>
        <option value="0">Holiday/Off</option>
      </select>
    </div>       
    </div>   
           
            <div class="form-group">
		<label>Enter Time Zone</label>
        <input type="time" onchange="onTimeChange(this.id)"  id="Tuesday_time" placeholder="time" required="required">
        <input type="hidden"  name="Tuesday_time" class="Tuesday_time"  id="Tuesday_time" >
        <input type="time" onchange="onTimeChange2(this.id)"  id="Tuesday_time2" placeholder="time" required="required">
        <input type="hidden"  name="Tuesday_time2" class="Tuesday_time2"  id="Tuesday_time2" >
      </div>
           
        <!-- wednesday -->
           <div class="form-group">
    <div class="mb-3">
      <label for="day" class="form-label"></label>
      <select class="form-control" name="Wednesday" id="Wednesday">
        <option value="3">Wednesday</option>
        <option value="0">Holiday/Off</option>
      </select>
    </div>       
    </div>   
           
            <div class="form-group">
		<label>Enter Time Zone</label>
    <input type="time" onchange="onTimeChange(this.id)" id="Wednesday_time" placeholder="time" required="required">
    <input type="hidden"  name="Wednesday_time" class="Wednesday_time"  id="Wednesday_time" >
    <input type="time" onchange="onTimeChange2(this.id)"  id="Wednesday_time2" placeholder="time" required="required">
        <input type="hidden"  name="Wednesday_time2" class="Wednesday_time2"  id="Wednesday_time2" >
      </div>
        
        <!--Thursday -->
        <div class="form-group">
    <div class="mb-3">
      <label for="day" class="form-label"></label>
      <select class="form-control" name="Thursday" id="Thursday">
        <option value="4">Thursday</option>
        <option value="0">Holiday/Off</option>
      </select>
    </div>       
    </div>   
           
            <div class="form-group">
		<label>Enter Time Zone</label>
        <input type="time"  id="Thursday_time" onchange="onTimeChange(this.id)" placeholder="time" required="required">
	      <input type="hidden"  name="Thursday_time" class="Thursday_time"  id="Thursday_time" >
        <input type="time" onchange="onTimeChange2(this.id)"  id="Thursday_time2" placeholder="time" required="required">
        <input type="hidden"  name="Thursday_time2" class="Thursday_time2"  id="Thursday_time2" >
      </div>
        <!-- wednesday -->
        <div class="form-group">
    <div class="mb-3">
      <label for="day" class="form-label"></label>
      <select class="form-control" name="Friday" id="Friday">
        <option value="5">Friday</option>
        <option value="0">Holiday/Off</option>
      </select>
    </div>       
    </div>   
           
            <div class="form-group">
		<label>Enter Time Zone</label>
        <input type="time"  id="Friday_time" onchange="onTimeChange(this.id)" placeholder="time" required="required">
        <input type="hidden" name="Friday_time"  class="Friday_time" id="Friday_time" >   
        <input type="time" onchange="onTimeChange2(this.id)"  id="Friday_time2" placeholder="time" required="required">
        <input type="hidden"  name="Friday_time2" class="Friday_time2"  id="Friday_time2" >
    
      </div>
        
        <!-- Saturday -->
        <div class="form-group">
    <div class="mb-3">
      <label for="day" class="form-label"></label>
      <select class="form-control" name="Saturday"  id="Saturday">
        <option value="6">Saturday</option>
        <option value="0">Holiday/Off</option>
      </select>
    </div>       
    </div>   
           
            <div class="form-group">
		<label>Enter Time Zone</label>
        <input type="time" onchange="onTimeChange(this.id)"  id="Saturday_time" placeholder="time" required="required">
                   <input type="hidden"  name="Saturday_time"  class="Saturday_time"  id="Saturday_time" >
                   <input type="time" onchange="onTimeChange2(this.id)"  id="Saturday_time2" placeholder="time" required="required">
        <input type="hidden"  name="Saturday_time2" class="Saturday_time2"  >
    
                  </div>
        
            <!-- <div class="form-group">
            <label>Enter Date</label>
        	<input type="date" 
            
             class="form-control" name="date" id="date" placeholder="Date" required="required">
            </div> -->
            
            <div class="form-group">
		<label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
            </div>
            <div class="form-group">
            <button type="submit" name="staff-submit" class="btn btn-dark btn-lg btn-block">Submit Reservation</button>
            </div>
        </form>
        <br><br>
    </div>
    
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function(){
  
  
$("select").on("change",function() { 
    
    var date_value=$(this).val();
    var id =$(this).attr("id")
    // alert(id)
  var days="#"+$(this).attr("id")+"_time";
  var days1="#"+$(this).attr("id")+"_time2";
  var days2="."+$(this).attr("id")+"_time";
  var days3="."+$(this).attr("id")+"_time2";
//   alert(days)

// alert(b);
    //   check that value if it is previous date or not
   
    if ( date_value == 0 ) {
      $(days).attr("type", "text")
      $(days).attr("readonly", true)
      $(days).val("0")
      $(days1).attr("type", "text")
      $(days1).attr("readonly", true)
      $(days1).val("0")
      $(days2).attr("type", "hidden")
      $(days2).attr("readonly", true)
      $(days2).val("0")
      $(days3).attr("type", "hidden")
      $(days3).attr("readonly", true)
      $(days3).val("0")
      // if upper alert occur then after dissappear of alert it will empty the field
        
  }else{
      $(days).attr("readonly", false)
      $(days).attr("type", "time")
      $(days1).attr("readonly", false)
      $(days1).attr("type", "time")
      $(days2).attr("readonly", false)
      $(days2).attr("type", "hidden")
      $(days2).val(" ")
      $(days3).attr("readonly", false)
      $(days3).attr("type", "hidden")
      $(days3).val(" ")
  
  }
  })
 
})

</script>

<?php
    }

    else {
        echo '	<p class="text-center text-danger"><br>You are currently not logged in!<br></p>
       <p class="text-center">In order to make a reservation you have to create an account!<br><br><p>';  
        
    }
    ?>

             
        </div>
    </div>
</div>
<br><br>


<?php
  include "footer.php";
  ?>
</div>