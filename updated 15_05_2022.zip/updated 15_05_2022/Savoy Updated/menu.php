<!DOCTYPE html>
<html lang="en">
<?php
     require 'includes/dbh.inc.php';
  ?>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Restaurant Menu</title>
  <link rel="stylesheet" href="./css/main.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
  <div class="container">
    <!-- <div class="menu">
      <h2 class="menu-group-heading">
        <U>BREADS</U>
        <hr>
      </h2>
      <div class="menu-group">
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">GARLIC & HERB TURKISH BREAD	</span>
              <span class="menu-item-price">$6.5</span>
            </h3>
            <p class="menu-item-description">
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">GARLIC, MUSTARD & CHEESE TURKISH BREAD	</span>
              <span class="menu-item-price">$7.5</span>
            </h3>
            <p class="menu-item-description">
            </p>
          </div>
        </div>
      </div> -->
<?php
$sql = "SELECT * FROM `menu`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $sql5 = "SELECT * FROM `category` where id={$row["cat_id"]}";
    $result5 = $conn->query($sql5);
    $row5 = $result5->fetch_assoc();
      ?>
      <h2 class="menu-group-heading">
        <U><?php echo $row5["name"] ?> </U>
        <hr>
      </h2>
      <div class="menu-group">
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">Product Name: <?php echo $row["p_name"] ?></span>
              <span class="menu-item-price"><?php echo $row["Price"] ?></span>
            </h3>
            <p class="menu-item-description">
              <h3>Description: </h3>
            <?php  readfile("description/".$row["description"])  ?>
            </p>
          </div>
        </div>
        <hr>
        <br>
        
        <hr>
          <?php
  }
} ?>
        <!--
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">SOUTH AUSTRALIAN ROCK OYSTERS (GF)</span>
              <span class="menu-item-price">$24</span>
            </h3>
            <p class="menu-item-description">
              Natural - with Shallot Vinaigrette
            </p>
          </div>
    
      </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">KILPATRICK- SMOKEY BACON </span>
              <span class="menu-item-price">$28</span>
            </h3>
            <p class="menu-item-description">
              BBQ sauce, Worcestershire sauce,Tabasco sauce & tomato sauce
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">CHICKEN SALAD (GF)	</span>
              <span class="menu-item-price">$23</span>
            </h3>
            <p class="menu-item-description">
              Breast fillet marinated with honey, dijon mustard, lime & chilli.
Chargrilled& served with fried zucchini salad
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">CALAMARI SALAD (GF)</span>
              <span class="menu-item-price">$24</span>
            </h3>
            <p class="menu-item-description">
              Tossed with radicchio, fennel, orange, tomato, cucumber, red
onion with a white balsamic vinaigrette
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">TOMATO MOZZARELLA (GF & V)</span>
              <span class="menu-item-price">$21</span>
            </h3>
            <p class="menu-item-description">
              Fresh seasonal tomato & buffalo mozzarella served with basil
pesto, sea salt, cracked pepper & extra virgin olive oil.
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">ANTIPASTO PLATTER	</span>
              <span class="menu-item-price">$28</span>
            </h3>
            <p class="menu-item-description">
              Spanish Serrano ham, salami, soft cheese, homemade dip,
kalamata olives, grilled vegetables & pita bread. Serves two
            </p>
          </div>
        </div>
      </div>
      <h2 class="menu-group-heading">
       <U>FROM THE GRILL</U>
       <hr>
      </h2>
      <div class="menu-group">
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">BLACK ANGUS RUMP 350G</span>
              <span class="menu-item-price">$29</span>
            </h3>
            <p class="menu-item-description">
              Lean cut, grain fed with a marble score of 2+.
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">BLACK ANGUS EYE FILLET 200G</span>
              <span class="menu-item-price">$36</span>
            </h3>
            <p class="menu-item-description">
              Grain fed, chargrilled with rasher of bacon to capture a smoky
hickory wood aroma
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">BLACK ANGUS SCOTCH FILLET 300G</span>
              <span class="menu-item-price">$36</span>
            </h3>
            <p class="menu-item-description">
              Richly marbled, tender & full of flavour.
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">BLACK ANGUS RIB EYE 750G</span>
              <span class="menu-item-price">$48</span>
            </h3>
            <p class="menu-item-description">
              200-250 days grain fed, full of flavour with a marble score of 3+.
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">BLACK ANGUS SIRLOIN 300G</span>
              <span class="menu-item-price">$38</span>
            </h3>
            <p class="menu-item-description">
              Tender succulent flavours.
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">WAGYU RUMP 300G</span>
              <span class="menu-item-price">$35</span>
            </h3>
            <p class="menu-item-description">
              Offering unique marbling, tenderness & flavours. Wheat & barley
fed with a marble score of 7+.
            </p>
          </div>
        </div>
        <div class="menu-item">
          <div class="menu-item-text">
            <h3 class="menu-item-heading">
              <span class="menu-item-name">LAMB CHOPS</span>
              <span class="menu-item-price">$34</span>
            </h3>
            <p class="menu-item-description">
              Four French cup chops, served with truffle oil mash, roasted
eggplant & Red Wine Jus.
            </p>
            <P> <B><I>*All steaks are gluten free & served with your choice of truffle oil mash,
              steakhouse chips or baked potato.</I></B>
            </P>
          </div>
        </div>
    </div>
    <h2 class="menu-group-heading">
      <U>MAINS</U>
      <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SLOW COOKED WAGYU SHORT RIB (GF)</span>
            <span class="menu-item-price">$34</span>
          </h3>
          <p class="menu-item-description">
            Marinated with spices, smoky BBQ sauce, red wine & slow cooked
            to perfection, served with creamy mash. Marble score of 5+.            
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">MEAT SKEWERS (GF</span>
            <span class="menu-item-price">$30</span>
          </h3>
          <p class="menu-item-description">
            Angus rump, chicken leg fillet, lamb chop, spicy sausages,
served with truffle mash
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">ROASTED MOROCCAN LAMB RUMP</span>
            <span class="menu-item-price">$32</span>
          </h3>
          <p class="menu-item-description">
            Served with creamy mash & Red Wine Jus.
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HALF CHICKEN</span>
            <span class="menu-item-price">$30</span>
          </h3>
          <p class="menu-item-description">
            Chargrilled and marinated with lemon thyme, grain mustard,
            paprika, blood orange & sesame oil, served with truffle oil mash.            
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">FISH OF THE DAY (GF)	</span>
            <span class="menu-item-price">$34</span>
          </h3>
          <p class="menu-item-description">
            Please see our friendly staff about our fish of the day.
Served with vegetables or salad
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">PANKO CRUMBED CHICKEN SCHNITZEL 350G</span>
            <span class="menu-item-price">$22</span>
          </h3>
          <p class="menu-item-description">
            Served with steakhouse chips & salad.
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">EGGPLANT DI RICOTTA (V)</span>
            <span class="menu-item-price">$24</span>
          </h3>
          <p class="menu-item-description">
            Oven baked thin chargrilled eggplant with swiss brown
mushrooms, ricotta, baby spinach, fresh tomato cream
sauce & Pecorino cheese.
          </p>
        </div>
      </div>
    </div>
    <h2 class="menu-group-heading">
      <U>SIDE DISHES</U>
      <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">STEAKHOUSE CHIPS SERVED WITH AIOLI</span>
            <span class="menu-item-price">$7.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SEASONAL POTATO WEDGES WITH SWEET CHILLI & SOUR CREAM</span>
            <span class="menu-item-price">$9.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">CREAMY MASH POTATO WITH TRUFFLE OIL</span>
            <span class="menu-item-price">$6.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">ROASTED BUTTER CARROTS (GF)</span>
            <span class="menu-item-price">$6.0</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SAUTÉED BABY SPINACH WITH GARLIC OIL (GF)</span>
            <span class="menu-item-price">$6.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SAUTÉED GARLIC MUSHROOMS (GF)</span>
            <span class="menu-item-price">$7.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">GARDEN SALAD (GF)</span>
            <span class="menu-item-price">$5.0</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">ROCKET, PEAR & PARMESAN SALAD</span>
            <span class="menu-item-price">$8.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
    </div>
    <h2 class="menu-group-heading">
     <U>DESSERTS</U>
     <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">COCONUT & LEMONGRASS CRÈME BRÛLÉE</span>
            <span class="menu-item-price">$13</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">TIRAMISU</span>
            <span class="menu-item-price">$13</span>
          </h3>
          <p class="menu-item-description">
            An elegant & rich traditional Italian dessert.
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">AFFOGATO DI SEMIFREDDO AL TORRONE	</span>
            <span class="menu-item-price">$16</span>
          </h3>
          <p class="menu-item-description">
            A nougat semi-frozen dessert, similar to ice cream but not as cold.
Doused in thick hot chocolate or espresso.
<P><B><I>*Add 30ml Amaretto or Frangelico +3</I></B></P>
          </p>
        </div>
      </div>  
    </div> 
    <h2 class="menu-group-heading">
      <U>FROM THE BAR</U>
      <hr>
      <P>SPARKLING</P>
      <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">TATACHILLA BRUT</span>
            <span class="menu-item-price">$36</span>
          </h3>
          <p class="menu-item-description">
            McLaren Vale, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">FOX CREEK ‘ARCTIC FOX’ GRAND CUVEE	</span>
            <span class="menu-item-price">$48</span>
          </h3>
          <p class="menu-item-description">
            McLaren Vale, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">BLEASDALE SPARKLING SHIRAZ 375ML</span>
            <span class="menu-item-price">$26</span>
          </h3>
          <p class="menu-item-description">
            Langhorne Creek, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">AMADIO PROSECCO</span>
            <span class="menu-item-price">$46</span>
          </h3>
          <p class="menu-item-description">
            Adelaide Hills, South Australia
          </p>
        </div>
      </div>
    </div>
    <h2 class="menu-group-heading">
      WHITE
      <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">MISTY LANE SAUVIGNON BLANC</span>
            <span class="menu-item-price">$36</span>
          </h3>
          <p class="menu-item-description">
            Adelaide Hills, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">O’LEARY WALKER SAUVIGNON BLANC</span>
            <span class="menu-item-price">$56</span>
          </h3>
          <p class="menu-item-description">
            Adelaide Hills, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HEIRLOOM CHARDONNAY</span>
            <span class="menu-item-price">$52</span>
          </h3>
          <p class="menu-item-description">
            Adelaide Hills, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SKILLOGALEE RIESLING	</span>
            <span class="menu-item-price">$56</span>
          </h3>
          <p class="menu-item-description">
            Clare Valley, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">YALUMBA PINOT GRIGIO</span>
            <span class="menu-item-price">$48</span>
          </h3>
          <p class="menu-item-description">
            Limestone Coast, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">DEVIATION ROAD PINOT GRIS</span>
            <span class="menu-item-price">$52</span>
          </h3>
          <p class="menu-item-description">
            Adelaide Hills, South Australia
          </p>
        </div>
      </div>
    </div>
    <h2 class="menu-group-heading">
      RED
      <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HUSTLE & VINE SANGIOVESE</span>
            <span class="menu-item-price">$48</span>
          </h3>
          <p class="menu-item-description">
            McLaren Vale, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HEWITSON ‘MISS HARRY’ GSM	</span>
            <span class="menu-item-price">$52</span>
          </h3>
          <p class="menu-item-description">
            Barossa Valley, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HEIRLOOM CHARDONNAY</span>
            <span class="menu-item-price">$52</span>
          </h3>
          <p class="menu-item-description">
            Adelaide Hills, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">ASHTON HILLS PINOT NOIR</span>
            <span class="menu-item-price">$64</span>
          </h3>
          <p class="menu-item-description">
            Piccadilly Valley, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">MORDRELLE MALBEC</span>
            <span class="menu-item-price">$64</span>
          </h3>
          <p class="menu-item-description">
            Langhorne Creek, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">BARRY BROS SHIRAZ CABERNET</span>
            <span class="menu-item-price">$48</span>
          </h3>
          <p class="menu-item-description">
            Clare Valley, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SC PANNELL TEMPRANILLO TOURIGA	</span>
            <span class="menu-item-price">$52</span>
          </h3>
          <p class="menu-item-description">
            McLaren Vale, South Australia
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">GRANT BURGE ‘HOLY TRINITY’ GSM	</span>
            <span class="menu-item-price">$89</span>
          </h3>
          <p class="menu-item-description">
            Barossa Valley, South Australia
          </p>
        </div>
      </div>
    </div> 
    <h2 class="menu-group-heading">
      TAP BEER & CIDER
      <hr>
    </h2>
    <div class="menu-group">
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">FURPHY</span>
            <span class="menu-item-price">$9.0</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HAHN SUPERDER</span>
            <span class="menu-item-price">$9.0</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">SUPERDRY 3.5</span>
            <span class="menu-item-price">$7.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">HEINEKEN</span>
            <span class="menu-item-price">$9.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">JAMES SQUIRE PALE ALE</span>
            <span class="menu-item-price">$9.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">JAMES SQUIRE APPLE CIDER</span>
            <span class="menu-item-price">$9.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">COOPERS PALE ALE</span>
            <span class="menu-item-price">$8.5</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div>
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">MOON DOG 'OLDMATE' PALE ALE</span>
            <span class="menu-item-price">$10</span>
          </h3>
          <p class="menu-item-description">
          </p>
        </div>
      </div> 
      <div class="menu-item">
        <div class="menu-item-text">
          <h3 class="menu-item-heading">
            <span class="menu-item-name">PRANCING PONY PALE ALE</span>
            <span class="menu-item-price">$10</span>
          </h3>
          <p class="menu-item-description">
        </div>
      </div>
      <div class="menu-item">
       <div class="menu-item-text">
         <h3 class="menu-item-heading">
           <span class="menu-item-name">LORD NELSON'3 SHEETS' PALE ALE</span>
           <span class="menu-item-price">$10</span>
         </h3>
         <p class="menu-item-description">
           </p>
       </div>
      </div>
    </div>
    <h2 class="menu-group-heading">
      COCKTAILS 
      <hr>
        </h2>
     <div class="menu-group">
       <div class="menu-item">
         <div class="menu-item-text">
           <h3 class="menu-item-heading">
             <span class="menu-item-name">APEROL SPRITZ</span>
             <span class="menu-item-price">$14</span>
           </h3>
           <p class="menu-item-description">
            -Refreshing & citrusy, perfect for a warm summer’s day.
           </p>
           <P>-Aperol & sparkling wine, soda & fresh orange</P>
         </div>
       </div>
       <div class="menu-item">
         <div class="menu-item-text">
           <h3 class="menu-item-heading">
             <span class="menu-item-name">MIDORI SPLICE</span>
             <span class="menu-item-price">$14</span>
           </h3>
           <p class="menu-item-description">
            -Fruity & tropical; tastes just like ice-cream
           </p>
           <P>-Midori, Malibu & pineapple juice</P>
         </div>
       </div>
       <P><B>
        * Ask our staff about more cocktail options.
        </B></P>
    </div> 
  </div>
</div>   -->
</body>
</html>