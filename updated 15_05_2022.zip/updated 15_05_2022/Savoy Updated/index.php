<!DOCTYPE html>
<html lang="en">
  <?php
     require 'includes/dbh.inc.php';
  ?>
<head>
  <title>Savoy Grill-Bar And Restaurant</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/font-awesome.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
<style>
body{
    background:#f1f1f1;
	font-family:sans-serif;
	margin:0;
}
span{
    font-size:3em;
	font-weight:bold;
}
form{
     float:right;
	 letter-spacing:1px;
	 font-size:17px;
}
input[type=text],input[type=password], input[type=submit], input[type=button]{
     padding:5px;
	 font-size:15px;
	 font-family:Arial;
	 border:none;
	 margin:1px;
}
input[type=submit]{
     background-color:Green;
	 color:white;
	 padding:5px 15px;
	 cursor:pointer;
	 font-weight:bold;
}
input[type=button]{
font-weight: bold;
}
button{
	font-size:15px;
	font-family:Arial;
	margin:1px;
  float:right;
  margin-right: 80px;
	color:black;
  cursor:pointer;
	padding:5px 15px 2px;
  font-weight:bold;
}
</style>
</head>
<body>
  <!-- page loader start -->
  <div class="page-loader"></div>
  <!-- page loader end -->
<!-- header start -->
  <header class="header">
    <div class="container">
      <div class="row justify-content-between align-items-center">
        <div class="logo">
          <a href="#"><img src="img/logo.png" alt="logo"></a>
        </div>
        <button type="button" class="nav-toggler">
          <span></span>
        </button>
		<form action="includes/login.inc.php" method="post">
			<div style="display:flex ; flex-wrap:wrap;">
			     <div><input type ="text" placeholder ="Username" name="mailuid"></div>
				 <div><input type ="password" placeholder ="Password" name="pwd"></div>
				 <div><input type ="submit" name="login-submit" value ="Login"></div>
			</div>
		</form>
    <a href="login1.php">
      <button>Sign up</button>
    </a>
        <nav class="nav">
          <ul>
            <li class="nav-item"><a href="#home">Home</a></li>
            <li class=nav-item-has-children">
              <a href="#">About Us <i class="fas fa-angle-down"></i></a>
              <div class="sub-menu">
                <ul>
                  <li><a href="#aboutus"><i><u>Our History</u></i></a></li>
                  <li><a href="#"><i><u>Our Team</u></i></a></li>
                  <li><a href="#"><u><i>Our Gallery</i></u></a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item"><a href="menu.php">Menu</a></li>
            <li class="nav-item"><a href="reservation.php">Book A Table</a></li>
            <li class=nav-item-has-children">
              <a href="#">Book an Event <i class="fas fa-angle-down"></i></a>
              <div class="sub-menu">
                <ul>
                  <li><a href="reservation.php"><u> <i> Birthday Event</i></u></a></li>
                  <li><a href="reservation.php"><u> <i> Other Event </i></u></a></li>
                </ul>
              </div>
            <li class="nav-item"><a href="contactform.html">Contact us</a></li>
            <li class="nav-item"><a href="#footer">Find Us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </header>
  <!-- header end -->
  <!-- home section start -->
  <section class="home-section" id="home">
    <div class="home-bg"></div>
    <div class="container">
      <div class="row min-vh-100 align-items-center">
        <div class="home-text" data-aos="fade-up" data-aos-duration="1000">
          <h1>Savoy Grill-Bar And Restaurant</h1>
          <p>"Serving The Delicious Food Since 2020"</p>
          <p><b><u>COVID-19 UPDATE</b> </u> </p>
          <P>What we continue to do at Savoy Grill-Bar and Restaurant to keep you safe.</P>
          <p>Since March 2020 we have made many changes in our restaurant to help keep our customers and employees safe.We continue to evaluate our policies and make necessary additionals and changes as the situation envolves and we learn more.</p>
          <a href="menu.php" class="btn btn-default"><b>See Our Menu</b></a>
          <a href="reservation.php" class="btn btn-default">Reserve a Table</a>
          <a href="leaveareview.html" class="btn btn-default">Leave a Review</a>
        </div>
      </div>
    </div>
  </section>
  <!-- home section end -->

  <!-- about section start -->
  <section class="about-section sec-padding" id="aboutus">
    <div class="container">
      <div class="row">
        <div class="section-title">
          <h2 data-title="About Us" data-aos="fade-up">Our History</h2>
        </div>
      </div>
      <div class="row">
        <div class="about-text" data-aos="fade-right">
           <h3>Welcome To Savoy Grill-Bar And Restaurant</h3>
           <p>John Doe</p>
           <p>I was born in Henley Beach.</p>
           <p>My schooling was at the Star of the Sea Primary & St Michael's College. My boys and daughter are second generation attending the same schools as myself.</p>
           <p>Over the last 30 years I've seen Henley beach grow from a small suburb to a vibrant and thriving precinct. I believe Henley Beach has become an iconic go to destination!</p>
           <p>My passion as a farmer and love of our country has led me to open a local fresh grill and bar restaurant realising a dream of mine. I really believe it's something we need in our community.</p>
           <p>The  Savoy Grill-Bar and restaurant are yours to enjoy as well. We look forward to having the pleasure of serving you all.</p>
           <p>John Doe and family.</p>
           <a href="menu.php" class="btn btn-default">check our menu</a>
        </div>
        <div class="about-img" data-aos="fade-left">
           <div class="img-box">
             <h3>1+ years of experience</h3>
             <img src="img/about-img.jpg" alt="about img">
           </div>
        </div>
      </div>
    </div>
  </section>
  <!-- about section end -->
<?php
 $sql = "SELECT * FROM `footer` WHERE id='1'"; 
 $run=mysqli_query($conn,$sql);
 if (mysqli_num_rows($run)>0) {
  $row=mysqli_fetch_assoc($run);
}
?>
  <!-- footer start -->
  <footer class="footer" id="footer">
    <div class="container">
      <div class="row">
        <div class="footer-item" data-aos="fade-up">
          <h3>our location</h3>
          <p><?php echo $row["location"] ?></p>
        </div>
        <div class="footer-item" data-aos="fade-up">
          <h3>opening hours</h3>
          <p><?php echo $row["hours"] ?><br><?php echo $row["opening_hour"] ?> </p>
        </div>
        <div class="footer-item" data-aos="fade-up">
          <h3>contact us</h3>
          <p><?php echo $row["number"] ?></p>
          <p><?php echo $row["Email"] ?></p>
          <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="copyright">
          &copy; 2021 - Designed by Team Dynamite (Dipendra, Sarbajeet, Saurav, Ashok and Alisha)
        </div>
      </div>
    </div>
  </footer>
  <!-- footer end -->
  <script src="js/aos.js"></script> 
<script src="js/script.js"></script>
</body>
</html>